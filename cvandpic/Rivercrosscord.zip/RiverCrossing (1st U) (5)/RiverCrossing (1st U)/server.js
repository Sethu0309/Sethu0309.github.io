const express = require("express");
const server = express();
const {
	writeFile
} = require("fs"); //fil system

// offentlige filer
server.use(express.static("./public"));

server.use(express.urlencoded({
	extended: false
}));

server.use(express.json());

server.post("/lagreting", (req, res) => {
	console.log("Brukeren prøver å lagre noe")
	const {
		ord
	} = req.body;
	writeFile("public/data/LastUserPlayed.txt", ord, (err, result) => {
		if (err) {
			console.log(err);
			return;
		}
	});
	return res.status(201).json({
		resultat: "alt gikk bra"
	})
});


server.all("*", (req, res) => {
	res.status(404).send("<h1>404 Ikke funnet. Nå har du driti deg ut</h1>");
});

server.listen(5000, () => {
	console.log("Serveren vår lytter på port 5000");
});
