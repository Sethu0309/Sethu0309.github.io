var PlayKnapp = document.querySelector("#PlayKnapp");
PlayKnapp.addEventListener("click", async (e) => {
	e.preventDefault();
	var brukernavn = document.querySelector("#brukernavnEl").value;
	var resultat = document.querySelector("#regResultatEl");

	if (brukernavn.length < 3) {
		resultat.innerHTML = "<p>Du må skrive brukernavn Lengre!</p>";
	} else {
		try {
			const {
				data
			} = await axios.get("/logginn", {
				params: {
					bruker: (brukernavn)
				}
			});
			if (data == "feil") {
				resultat.innerHTML = "<p>" + data + "</p>";
			} else {
				sessionStorage.hemmelig = data;
				sessionStorage.brukernavn = brukernavn;
				window.location.replace("saukålulv.html");
			}
		} catch (error) {
			resultat.innerHTML = "<p>Feil" + error.responseText + "</p>";
		}
	}

});
